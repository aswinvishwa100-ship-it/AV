# AV Pixel Home

A small, native Android launcher inspired by Pixel's clean home screen. Designed for Android 13 on the OnePlus Nord CE (EB2101); supports Android 8 and newer. This is an independent prototype, not Google's Pixel Launcher or an Android OS update.

## Included

- Soft green background, live clock, and date with calendar shortcut
- Searchable four-column app drawer; swipe up on the home background or tap the search bar
- Four favorites: long-press an app to add/remove it or open its system app info
- Web search handed to your browser
- Home settings with the system default-launcher picker
- No network, location, contacts, accessibility, or storage permissions. Favorites stay in local app preferences. Web searches open an external browser.

The initial dock shows the first four apps alphabetically until favorites are saved. App icons come from installed apps. Widgets, folders, icon packs, wallpaper selection, notification badges, and system Quick Settings changes are not implemented.

## Build

Use Gradle 8.9, JDK 17 or 21, and Android SDK platform 35 / build tools 35.0.0. Set `ANDROID_HOME` to your SDK directory, or supply `sdk.dir` in an untracked `local.properties`.

```sh
gradle :app:assembleDebug :app:lintDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`. Debug builds are for testing, not Play Store release.

## Install on the phone

1. Back up any home-screen arrangement you want to keep, such as screenshots.
2. Transfer the APK to the phone and open it. Temporarily allow installation from that file manager when Android prompts, then turn that permission back off afterward.
3. Open **AV Pixel Home**. Tap **Home settings → Set default Home**, or choose it under **Settings → Apps → Default apps → Home app**. Menu wording may vary.
4. To return to OxygenOS, choose the original OnePlus launcher in the same Home app settings. You can then uninstall AV normally.

No root, bootloader unlocking, firmware flashing, or data wipe is needed.

## Device smoke test

- Confirm Home returns to AV, including after launching another app.
- Open the drawer, search an installed app, launch it, and return Home.
- Check an unmatched search and use web search with a configured browser.
- Long-press apps to add/remove favorites; confirm they persist after restarting AV.
- Open app info; use the date shortcut with a calendar installed.
- Check Back returns from the drawer to Home and test your preferred OxygenOS navigation mode.
- Check large font/display settings, screen rotation, TalkBack labels, and reopening after a reboot.
- Switch back to the OnePlus launcher before uninstalling.

Phone testing remains required. A successful build is not a verification of OxygenOS gesture integration or accessibility.

## Build verified in this cloud environment

Gradle dependency resolution was blocked by Java networking in this instance. The APK was instead built with Google SDK build tools 35.0.0 and Eclipse compiler 3.39.0, then aligned, debug-signed, and signature-verified. SDK/compiler downloads were checked against publisher checksums. No runtime device or emulator test has been performed; Gradle lint has not run.

Repeat the tested build here:

```sh
ANDROID_HOME=/workspace/tooling/android-sdk ECJ_JAR=/workspace/tooling/ecj.jar ./scripts/build-apk.sh
```

On a machine with a full JDK, omit `ECJ_JAR`. The alternative script needs Python 3, zip, and SDK build tools 35.0.0. Output: `app/build/manual/av-pixel-home-debug.apk`. Keep the debug keystore in the ignored build folder to update this test installation; deleting it changes the signing identity and may require uninstalling the previous test app.
