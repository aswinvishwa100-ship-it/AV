#!/usr/bin/env bash
# Build a test APK without Gradle dependency resolution. Requires JDK and SDK 35.
set -euo pipefail
cd "$(dirname "$0")/.."
: "${ANDROID_HOME:?Set ANDROID_HOME to your Android SDK directory}"
sdk_tools="$ANDROID_HOME/build-tools/35.0.0"
android_jar="$ANDROID_HOME/platforms/android-35/android.jar"
out="$PWD/app/build/manual"
mkdir -p "$out/classes" "$out/dex" "$out/signing"
python3 - "$out/AndroidManifest.xml" <<'PY'
import sys,xml.etree.ElementTree as E
E.register_namespace('android','http://schemas.android.com/apk/res/android')
r=E.parse('app/src/main/AndroidManifest.xml');r.getroot().set('package','com.av.oxygenhome');r.write(sys.argv[1])
PY
"$sdk_tools/aapt2" compile --dir app/src/main/res -o "$out/resources.zip"
"$sdk_tools/aapt2" link -o "$out/unsigned.apk" -I "$android_jar" --manifest "$out/AndroidManifest.xml" --min-sdk-version 29 --target-sdk-version 35 --version-code 1 --version-name 0.1 "$out/resources.zip"
if command -v javac >/dev/null; then
 javac --release 8 -classpath "$android_jar" -d "$out/classes" app/src/main/java/com/av/oxygenhome/*.java
else
 : "${ECJ_JAR:?Install a JDK or set ECJ_JAR to Eclipse compiler 3.39.0}"
 java -jar "$ECJ_JAR" -8 -proc:none -classpath "$android_jar" -d "$out/classes" app/src/main/java/com/av/oxygenhome/*.java
fi
find "$out/classes" -name '*.class' -print0 | xargs -0 "$sdk_tools/d8" --lib "$android_jar" --min-api 29 --output "$out/dex"
(cd "$out/dex" && zip -q -j "$out/unsigned.apk" classes*.dex)
"$sdk_tools/zipalign" -f -p 4 "$out/unsigned.apk" "$out/aligned.apk"
if [ ! -f "$out/signing/debug.keystore" ]; then
 keytool -genkeypair -keystore "$out/signing/debug.keystore" -storepass android -keypass android -alias androiddebugkey -dname 'CN=Android Debug,O=Android,C=US' -keyalg RSA -keysize 2048 -validity 10000 >/dev/null 2>&1
fi
"$sdk_tools/apksigner" sign --ks "$out/signing/debug.keystore" --ks-pass pass:android --out "$out/av-oxygen-home-debug.apk" "$out/aligned.apk"
"$sdk_tools/apksigner" verify "$out/av-oxygen-home-debug.apk"
"$sdk_tools/aapt2" dump badging "$out/av-oxygen-home-debug.apk" | head -n 8
printf 'APK built: %s\n' "$out/av-oxygen-home-debug.apk"
