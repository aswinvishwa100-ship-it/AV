package com.av.oxygenhome;
import android.app.Activity;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.*;
import android.content.*;
class Screen extends Activity {
    static final int BG=0xfff5f3f0, INK=0xff202124, MUTED=0xff6e7074, RED=0xffd62d38;
    int dp(float n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
    TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER);return t;}
    GradientDrawable shape(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    TextView button(String s,int color,Runnable action){TextView t=label(s,16,color);t.setBackground(shape(0xffffffff,24));t.setPadding(dp(10),dp(12),dp(10),dp(12));t.setFocusable(true);t.setOnClickListener(v->action.run());return t;}
    void open(Intent i){try{startActivity(i);}catch(ActivityNotFoundException|SecurityException e){Toast.makeText(this,"Action unavailable. Check your default phone app.",Toast.LENGTH_LONG).show();}}
    LinearLayout column(){LinearLayout c=new LinearLayout(this);c.setOrientation(1);c.setPadding(dp(24),dp(16),dp(24),dp(12));c.setBackgroundColor(BG);c.setFitsSystemWindows(true);setContentView(c);return c;}
}
