package com.av.oxygenhome;
import android.Manifest;
import android.app.role.RoleManager;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.telecom.TelecomManager;
import android.telephony.PhoneNumberUtils;
import android.view.*;
import android.widget.*;

public class DialActivity extends Screen {
    EditText number;
    @Override public void onCreate(Bundle b){super.onCreate(b);build();readIntent(getIntent());if(b!=null)number.setText(b.getString("number",""));if(getIntent().getBooleanExtra("setup",false))setup();}
    @Override protected void onSaveInstanceState(Bundle b){b.putString("number",number.getText().toString());super.onSaveInstanceState(b);}
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);readIntent(i);}
    private void readIntent(Intent i){if(i.getData()!=null&&"tel".equals(i.getData().getScheme()))number.setText(i.getData().getSchemeSpecificPart());}
    private void build(){LinearLayout root=column();LinearLayout top=new LinearLayout(this);top.addView(button("‹",INK,()->finish()),new LinearLayout.LayoutParams(dp(48),dp(48)));top.addView(label("Phone",26,INK),new LinearLayout.LayoutParams(0,dp(48),1));top.addView(button("Setup",RED,()->setup()),new LinearLayout.LayoutParams(dp(76),dp(48)));root.addView(top);
        TextView info=label("AV Oxygen · Phone",13,MUTED);info.setPadding(0,dp(12),0,dp(8));root.addView(info);
        number=new EditText(this);number.setInputType(android.text.InputType.TYPE_CLASS_PHONE);number.setTextSize(32);number.setSingleLine();number.setGravity(Gravity.CENTER);number.setHint("Enter number");number.setContentDescription("Phone number");number.setShowSoftInputOnFocus(false);root.addView(number,new LinearLayout.LayoutParams(-1,dp(80)));
        TextView erase=button("⌫  Delete",MUTED,()->{int a=number.getSelectionStart(),b=number.getSelectionEnd();if(a!=b)number.getText().delete(Math.min(a,b),Math.max(a,b));else if(a>0)number.getText().delete(a-1,a);});erase.setOnLongClickListener(v->{number.setText("");return true;});root.addView(erase,new LinearLayout.LayoutParams(-1,dp(46)));
        String[] digits={"1","2","3","4","5","6","7","8","9","*","0","#"};String[] letters={"","ABC","DEF","GHI","JKL","MNO","PQRS","TUV","WXYZ","","+",""};
        LinearLayout keypad=new LinearLayout(this);keypad.setOrientation(1);for(int row=0;row<4;row++){LinearLayout line=new LinearLayout(this);for(int col=0;col<3;col++){final String digit=digits[row*3+col];TextView key=button(digit+"\n"+letters[row*3+col],INK,()->insert(digit));key.setTextSize(24);key.setContentDescription(digit.equals("*")?"Star":digit.equals("#")?"Hash":digit);if(digit.equals("0"))key.setOnLongClickListener(v->{insert("+");return true;});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.setMargins(dp(3),dp(3),dp(3),dp(3));line.addView(key,lp);}keypad.addView(line,new LinearLayout.LayoutParams(-1,0,1));}root.addView(keypad,new LinearLayout.LayoutParams(-1,0,1));
        TextView call=button("Call",0xffffffff,()->place());call.setBackground(shape(RED,30));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(60));cp.setMargins(0,dp(12),0,dp(8));root.addView(call,cp);
        TextView system=button("Use system phone",MUTED,()->systemDial());root.addView(system,new LinearLayout.LayoutParams(-1,dp(46)));
    }
    void insert(String d){int a=Math.max(0,number.getSelectionStart()),b=Math.max(a,number.getSelectionEnd());number.getText().replace(a,b,d);}
    boolean isDefault(){TelecomManager t=getSystemService(TelecomManager.class);return t!=null&&getPackageName().equals(t.getDefaultDialerPackage());}
    void place(){String n=PhoneNumberUtils.stripSeparators(number.getText().toString().trim());if(n.isEmpty()){Toast.makeText(this,"Enter a number first",0).show();return;}if(!isDefault()){setup();return;}if(checkSelfPermission(Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.CALL_PHONE},10);return;}try{getSystemService(TelecomManager.class).placeCall(Uri.fromParts("tel",n,null),new Bundle());}catch(SecurityException|IllegalArgumentException e){Toast.makeText(this,"Call could not start. Check permissions, SIM, and phone settings.",1).show();}}
    void systemDial(){TelecomManager t=getSystemService(TelecomManager.class);String p=t==null?null:t.getSystemDialerPackage();if(p==null||p.equals(getPackageName())){Toast.makeText(this,"System phone app unavailable",0).show();return;}open(new Intent(Intent.ACTION_DIAL,Uri.fromParts("tel",number.getText().toString(),null)).setPackage(p));}
    void setup(){new android.app.AlertDialog.Builder(this).setTitle("Phone app setup").setMessage("Select AV as your default phone app to use its call screen. Allow call and notification permissions when requested. Test incoming, outgoing, and lock-screen calls with a trusted contact before relying on this prototype.\n\nNo contacts or call history are collected. Your system phone remains available.").setPositiveButton("Continue",(dialog,which)->setupChoices()).setNegativeButton("Cancel",null).show();}
    void setupChoices(){new android.app.AlertDialog.Builder(this).setTitle("Configure AV Phone").setItems(new String[]{"Choose default phone app","Allow call notifications","Incoming call full-screen settings","App permissions"},(d,w)->{if(w==0){RoleManager r=getSystemService(RoleManager.class);if(r!=null&&r.isRoleAvailable(RoleManager.ROLE_DIALER))startActivityForResult(r.createRequestRoleIntent(RoleManager.ROLE_DIALER),20);else open(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS));}else if(w==1){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},11);else open(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()));}else if(w==2){if(Build.VERSION.SDK_INT>=34)open(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,Uri.parse("package:"+getPackageName())));else Toast.makeText(this,"On Android 13, allow call notifications in notification settings.",1).show();}else open(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}).setNegativeButton("Close",null).show();}
    @Override public void onRequestPermissionsResult(int code,String[] p,int[] results){super.onRequestPermissionsResult(code,p,results);if(code==10)Toast.makeText(this,results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED?"Permission granted. Tap Call to continue.":"Call permission denied. Use system phone instead.",1).show();}
}
