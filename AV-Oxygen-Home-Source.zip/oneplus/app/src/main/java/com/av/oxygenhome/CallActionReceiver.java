package com.av.oxygenhome;
import android.content.*;
import android.telecom.*;
public class CallActionReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent i){Call c=CallService.current();if(c==null)return;String a=i.getAction();if("answer".equals(a)&&c.getState()==Call.STATE_RINGING){c.answer(VideoProfile.STATE_AUDIO_ONLY);if(CallService.connected!=null)CallService.connected.showUi();}else if("decline".equals(a)&&c.getState()==Call.STATE_RINGING)c.reject(false,null);else if("end".equals(a))c.disconnect();}
}
