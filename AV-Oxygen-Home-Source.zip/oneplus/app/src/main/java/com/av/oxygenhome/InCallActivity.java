package com.av.oxygenhome;
import android.content.*;
import android.os.*;
import android.telecom.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class InCallActivity extends Screen {
    private final Handler timer=new Handler(Looper.getMainLooper());
    private TextView duration;
    private final Runnable tick=new Runnable(){public void run(){updateDuration();timer.postDelayed(this,1000);}};
    private final BroadcastReceiver updates=new BroadcastReceiver(){public void onReceive(Context c,Intent i){render();}};
    @Override public void onCreate(Bundle b){super.onCreate(b);setShowWhenLocked(true);setTurnScreenOn(true);render();}
    @Override protected void onResume(){super.onResume();IntentFilter f=new IntentFilter(CallService.CHANGED);if(Build.VERSION.SDK_INT>=33)registerReceiver(updates,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(updates,f);render();timer.post(tick);}
    @Override protected void onPause(){timer.removeCallbacks(tick);unregisterReceiver(updates);super.onPause();}
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);render();}
    private void updateDuration(){Call c=CallService.current();if(c==null||duration==null)return;long time=c.getDetails()==null?0:c.getDetails().getConnectTimeMillis();if(c.getState()==Call.STATE_ACTIVE&&time>0){long sec=Math.max(0,(System.currentTimeMillis()-time)/1000);duration.setText(String.format(Locale.getDefault(),"%02d:%02d",sec/60,sec%60));}}
    private void render(){Call c=CallService.current();if(c==null){finish();return;}LinearLayout root=column();TextView brand=label("AV OXYGEN PHONE",12,RED);brand.setLetterSpacing(.16f);root.addView(brand,new LinearLayout.LayoutParams(-1,dp(42)));root.addView(new Space(this),new LinearLayout.LayoutParams(1,0,1));
        TextView avatar=label("↗",52,RED);avatar.setBackground(shape(0xfff8e3e2,60));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(108),dp(108));ap.gravity=Gravity.CENTER;root.addView(avatar,ap);
        TextView caller=label(CallService.caller(c),30,INK);caller.setMaxLines(2);caller.setEllipsize(android.text.TextUtils.TruncateAt.END);caller.setPadding(0,dp(22),0,dp(12));root.addView(caller);
        String state=c.getState()==Call.STATE_RINGING?"Incoming call":c.getState()==Call.STATE_HOLDING?"On hold":c.getState()==Call.STATE_ACTIVE?"Connected":c.getState()==Call.STATE_DIALING?"Calling…":c.getState()==Call.STATE_CONNECTING?"Connecting…":"Phone call";
        duration=label(state,16,MUTED);root.addView(duration);updateDuration();if(CallService.calls.size()>1)root.addView(label(CallService.calls.size()+" calls · use Hold / Resume to switch",12,MUTED));root.addView(new Space(this),new LinearLayout.LayoutParams(1,0,1));
        if(c.getState()==Call.STATE_RINGING){root.addView(button("Answer",0xff247a51,()->c.answer(VideoProfile.STATE_AUDIO_ONLY)),new LinearLayout.LayoutParams(-1,dp(62)));TextView decline=button("Decline",RED,()->c.reject(false,null));LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(-1,dp(62));dl.topMargin=dp(12);root.addView(decline,dl);}
        else{CallService service=CallService.connected;CallAudioState audio=service==null?null:service.getCallAudioState();LinearLayout row=new LinearLayout(this);row.addView(button(audio!=null&&audio.isMuted()?"Unmute":"Mute",INK,()->{if(service!=null){CallAudioState a=service.getCallAudioState();if(a!=null)service.setMuted(!a.isMuted());}}),new LinearLayout.LayoutParams(0,dp(64),1));row.addView(button(audio!=null&&audio.getRoute()==CallAudioState.ROUTE_SPEAKER?"Speaker on":"Speaker",INK,()->{if(service!=null){CallAudioState a=service.getCallAudioState();if(a!=null){int route=a.getRoute()==CallAudioState.ROUTE_SPEAKER?CallAudioState.ROUTE_WIRED_OR_EARPIECE:CallAudioState.ROUTE_SPEAKER;service.setAudioRoute(route);}}}),new LinearLayout.LayoutParams(0,dp(64),1));row.addView(button("Keypad",INK,()->tones(c)),new LinearLayout.LayoutParams(0,dp(64),1));root.addView(row);
            if(c.getDetails()!=null&&c.getDetails().can(Call.Details.CAPABILITY_HOLD))root.addView(button(c.getState()==Call.STATE_HOLDING?"Resume":"Hold",INK,()->{if(c.getState()==Call.STATE_HOLDING)c.unhold();else c.hold();}),new LinearLayout.LayoutParams(-1,dp(52)));
            if(CallService.calls.size()>1)root.addView(button("Choose call",INK,()->chooseCall()),new LinearLayout.LayoutParams(-1,dp(52)));
            TextView end=button("End call",0xffffffff,()->c.disconnect());end.setBackground(shape(RED,32));LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,dp(64));ep.topMargin=dp(18);root.addView(end,ep);
        }
        root.addView(button("Return to Home",MUTED,()->{open(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));}),new LinearLayout.LayoutParams(-1,dp(52)));
    }
    private void chooseCall(){ArrayList<Call> copy=new ArrayList<>(CallService.calls);String[] names=new String[copy.size()];for(int i=0;i<copy.size();i++)names[i]=CallService.caller(copy.get(i))+(copy.get(i).getState()==Call.STATE_HOLDING?" · held":"");new android.app.AlertDialog.Builder(this).setTitle("Resume a held call").setItems(names,(d,w)->{Call chosen=copy.get(w);if(chosen.getState()==Call.STATE_HOLDING)chosen.unhold();}).setNegativeButton("Close",null).show();}
    private void tones(Call c){LinearLayout keys=new LinearLayout(this);keys.setOrientation(1);for(String digits:new String[]{"123","456","789","*0#"}){LinearLayout row=new LinearLayout(this);for(char digit:digits.toCharArray()){TextView b=button(String.valueOf(digit),INK,()->{c.playDtmfTone(digit);timer.postDelayed(()->c.stopDtmfTone(),160);});row.addView(b,new LinearLayout.LayoutParams(0,dp(58),1));}keys.addView(row);}new android.app.AlertDialog.Builder(this).setTitle("Call keypad").setView(keys).setNegativeButton("Close",(d,w)->c.stopDtmfTone()).setOnDismissListener(d->c.stopDtmfTone()).show();}
}
