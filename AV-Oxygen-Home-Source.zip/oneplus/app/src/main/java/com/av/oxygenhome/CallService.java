package com.av.oxygenhome;
import android.app.*;
import android.content.*;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.telecom.*;
import java.util.*;

/** Android binds this only while AV holds the user-selected default dialer role. */
public class CallService extends InCallService {
    static CallService connected;
    static final ArrayList<Call> calls=new ArrayList<>();
    static final String CHANGED="com.av.oxygenhome.CALL_CHANGED";
    static final String CHANNEL="calls";
    private final HashMap<Call,Call.Callback> callbacks=new HashMap<>();
    private boolean uiOpened;
    @Override public void onCreate(){super.onCreate();connected=this;NotificationChannel ch=new NotificationChannel(CHANNEL,"Phone calls",NotificationManager.IMPORTANCE_HIGH);ch.setDescription("Incoming and ongoing call controls");ch.setSound(null,null);ch.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);getSystemService(NotificationManager.class).createNotificationChannel(ch);}
    @Override public void onCallAdded(Call c){super.onCallAdded(c);if(!calls.contains(c))calls.add(c);Call.Callback cb=new Call.Callback(){@Override public void onStateChanged(Call c,int s){changed();}@Override public void onDetailsChanged(Call c,Call.Details d){changed();}};callbacks.put(c,cb);c.registerCallback(cb);changed();if(!uiOpened){uiOpened=true;showUi();}}
    @Override public void onCallRemoved(Call c){Call.Callback cb=callbacks.remove(c);if(cb!=null)c.unregisterCallback(cb);calls.remove(c);changed();super.onCallRemoved(c);}
    @Override public void onCallAudioStateChanged(CallAudioState state){super.onCallAudioStateChanged(state);changed();}
    @Override public void onBringToForeground(boolean showDialpad){showUi();}
    static Call current(){for(Call c:calls)if(c.getState()==Call.STATE_RINGING)return c;for(Call c:calls)if(c.getState()==Call.STATE_ACTIVE)return c;for(Call c:calls)if(c.getState()!=Call.STATE_DISCONNECTED&&c.getState()!=Call.STATE_DISCONNECTING)return c;return null;}
    static String caller(Call c){if(c==null||c.getDetails()==null)return "Phone call";Call.Details d=c.getDetails();String name=d.getCallerDisplayName();if(name!=null&&!name.trim().isEmpty())return name;return d.getHandle()==null?"Private number":d.getHandle().getSchemeSpecificPart();}
    void showUi(){try{startActivity(new Intent(this,InCallActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP));}catch(RuntimeException ignored){/* The call notification remains the supported fallback. */}}
    void changed(){sendBroadcast(new Intent(CHANGED).setPackage(getPackageName()));Call c=current();NotificationManager nm=getSystemService(NotificationManager.class);if(c==null){nm.cancel(81);if(calls.isEmpty())uiOpened=false;return;}boolean ringing=c.getState()==Call.STATE_RINGING;PendingIntent content=PendingIntent.getActivity(this,1,new Intent(this,InCallActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=new Notification.Builder(this,CHANNEL).setSmallIcon(comIcon()).setContentTitle(caller(c)).setContentText(ringing?"Incoming call":"Call in progress").setContentIntent(content).setCategory(Notification.CATEGORY_CALL).setOngoing(true).setOnlyAlertOnce(true).setVisibility(Notification.VISIBILITY_PRIVATE);
        if(Build.VERSION.SDK_INT>=31){Person person=new Person.Builder().setName(caller(c)).setImportant(true).build();b.setStyle(ringing?Notification.CallStyle.forIncomingCall(person,action("decline",2),action("answer",3)):Notification.CallStyle.forOngoingCall(person,action("end",4)));}else{if(ringing)b.addAction(new Notification.Action.Builder(null,"Answer",action("answer",3)).build());b.addAction(new Notification.Action.Builder(null,ringing?"Decline":"End call",action(ringing?"decline":"end",4)).build());}
        if(ringing)b.setFullScreenIntent(content,true);try{nm.notify(81,b.build());}catch(SecurityException ignored){}
    }
    Icon comIcon(){return Icon.createWithResource(this,getResources().getIdentifier("ic_launcher","drawable",getPackageName()));}
    PendingIntent action(String a,int id){return PendingIntent.getBroadcast(this,id,new Intent(this,CallActionReceiver.class).setAction(a),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    @Override public void onDestroy(){for(Map.Entry<Call,Call.Callback> e:callbacks.entrySet())e.getKey().unregisterCallback(e.getValue());callbacks.clear();calls.clear();connected=null;getSystemService(NotificationManager.class).cancel(81);sendBroadcast(new Intent(CHANGED).setPackage(getPackageName()));super.onDestroy();}
}
