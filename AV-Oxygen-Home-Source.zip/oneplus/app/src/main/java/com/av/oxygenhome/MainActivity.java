package com.av.oxygenhome;

import android.app.*;
import android.app.role.RoleManager;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.provider.Settings;
import android.service.notification.StatusBarNotification;
import android.text.*;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    static final int INK=0xff202124, MUTED=0xff6e7074, RED=0xffd62d38, BG=0xfff5f3f0;
    private LinearLayout root;
    private String page="home";
    private final ArrayList<ResolveInfo> apps=new ArrayList<>();
    private android.content.SharedPreferences prefs;
    private float downY;
    private final BroadcastReceiver changes=new BroadcastReceiver(){public void onReceive(Context c,Intent i){if(page.equals("panel"))panel();}};
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable tick=new Runnable(){public void run(){if(page.equals("home"))home();handler.postDelayed(this,60000);}};
    @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("home",MODE_PRIVATE);load();home();handler.postDelayed(tick,60000);}
    @Override protected void onResume(){super.onResume();load();IntentFilter f=new IntentFilter(NotificationBridge.CHANGED);if(Build.VERSION.SDK_INT>=33)registerReceiver(changes,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(changes,f);if(root!=null){if(page.equals("panel"))panel();else if(page.equals("apps"))drawer();else home();}}
    @Override protected void onPause(){unregisterReceiver(changes);super.onPause();}
    @Override protected void onDestroy(){handler.removeCallbacks(tick);super.onDestroy();}
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);home();}
    int dp(float n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
    GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    TextView button(String s,Runnable action){TextView t=text(s,15,INK);t.setGravity(Gravity.CENTER);t.setPadding(dp(14),dp(12),dp(14),dp(12));t.setBackground(shape(Color.WHITE,24));t.setFocusable(true);t.setOnClickListener(v->action.run());return t;}
    void base(String p){page=p;root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(22),dp(14),dp(22),dp(12));root.setBackgroundColor(BG);root.setFitsSystemWindows(true);setContentView(root);root.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){downY=e.getY();return true;}if(e.getAction()==MotionEvent.ACTION_UP){float delta=e.getY()-downY;if(delta < -dp(65))drawer();else if(delta>dp(65))panel();v.performClick();return true;}return true;});}
    void load(){apps.clear();apps.addAll(getPackageManager().queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),0));apps.removeIf(a->a.activityInfo.packageName.equals(getPackageName()));apps.sort((a,b)->name(a).compareToIgnoreCase(name(b)));}
    String name(ResolveInfo a){return a.loadLabel(getPackageManager()).toString();}
    String key(ResolveInfo a){return new ComponentName(a.activityInfo.packageName,a.activityInfo.name).flattenToString();}
    void home(){base("home");
        LinearLayout top=new LinearLayout(this);TextView brand=text("NEVER SETTLE",12,INK);brand.setLetterSpacing(.18f);top.addView(brand,new LinearLayout.LayoutParams(0,dp(44),1));top.addView(button("≡",()->panel()),new LinearLayout.LayoutParams(dp(48),dp(44)));root.addView(top);
        LinearLayout hours=new LinearLayout(this);String h=new SimpleDateFormat("HH",Locale.getDefault()).format(new Date());TextView first=text(h.substring(0,1),92,RED);first.setTypeface(Typeface.create("sans-serif-light",0));TextView second=text(h.substring(1),92,INK);second.setTypeface(first.getTypeface());hours.addView(first);hours.addView(second);root.addView(hours);
        TextView minute=text(new SimpleDateFormat("mm",Locale.getDefault()).format(new Date()),88,INK);minute.setTypeface(Typeface.create("sans-serif-light",0));minute.setPadding(0,-dp(24),0,0);root.addView(minute);
        TextView date=text(new SimpleDateFormat("EEEE, d MMMM",Locale.getDefault()).format(new Date()),16,MUTED);root.addView(date);date.setOnClickListener(v->open(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR)));
        root.addView(new Space(this),new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout cards=new LinearLayout(this);TextView phone=button("↗  Phone",()->startActivity(new Intent(this,DialActivity.class)));phone.setTextColor(RED);cards.addView(phone,new LinearLayout.LayoutParams(0,dp(56),1));Space gap=new Space(this);cards.addView(gap,new LinearLayout.LayoutParams(dp(12),1));cards.addView(button("Notifications",()->panel()),new LinearLayout.LayoutParams(0,dp(56),1));root.addView(cards);
        LinearLayout dock=new LinearLayout(this);Set<String> selected=prefs.getStringSet("favorites",Collections.emptySet());ArrayList<ResolveInfo> fav=new ArrayList<>();for(ResolveInfo a:apps)if(selected.contains(key(a)))fav.add(a);if(!prefs.contains("favorites"))for(ResolveInfo a:apps){if(fav.size()==4)break;fav.add(a);}for(ResolveInfo a:fav)dock.addView(tile(a,false),new LinearLayout.LayoutParams(0,dp(88),1));root.addView(dock);
        root.addView(button("⌕   Search apps",()->drawer()),new LinearLayout.LayoutParams(-1,dp(54)));
        TextView footer=text("↑ Apps   ·   ↓ Notifications   ·   Settings",12,MUTED);footer.setGravity(Gravity.CENTER);footer.setPadding(0,dp(12),0,0);footer.setOnClickListener(v->settings());root.addView(footer);
        root.setOnLongClickListener(v->{settings();return true;});
    }
    View tile(ResolveInfo a,boolean labels){LinearLayout b=new LinearLayout(this);b.setOrientation(1);b.setGravity(Gravity.CENTER);b.setPadding(dp(3),dp(8),dp(3),dp(8));ImageView icon=new ImageView(this);icon.setImageDrawable(a.loadIcon(getPackageManager()));b.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));if(labels){TextView label=text(name(a),12,INK);label.setGravity(Gravity.CENTER);label.setMaxLines(2);label.setEllipsize(TextUtils.TruncateAt.END);b.addView(label,new LinearLayout.LayoutParams(-1,dp(36)));}b.setContentDescription(name(a));b.setFocusable(true);b.setOnClickListener(v->open(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(new ComponentName(a.activityInfo.packageName,a.activityInfo.name)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)));b.setOnLongClickListener(v->{new AlertDialog.Builder(this).setTitle(name(a)).setItems(new String[]{"Add / remove favorite","App info"},(d,w)->{if(w==1){open(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+a.activityInfo.packageName)));return;}Set<String> f=new HashSet<>(prefs.getStringSet("favorites",Collections.emptySet()));if(!f.remove(key(a))){if(f.size()==4){Toast.makeText(this,"Remove a favorite first",Toast.LENGTH_SHORT).show();return;}f.add(key(a));}prefs.edit().putStringSet("favorites",f).apply();if(page.equals("home"))home();}).show();return true;});return b;}
    void header(String name){LinearLayout row=new LinearLayout(this);row.addView(button("‹",()->home()),new LinearLayout.LayoutParams(dp(48),dp(48)));TextView title=text(name,26,INK);title.setTypeface(null,Typeface.BOLD);row.addView(title,new LinearLayout.LayoutParams(0,dp(48),1));root.addView(row);}
    void drawer(){base("apps");header("All apps");EditText q=new EditText(this);q.setSingleLine();q.setHint("Search installed apps");q.setTextSize(16);q.setPadding(dp(18),0,dp(18),0);q.setBackground(shape(Color.WHITE,24));LinearLayout.LayoutParams qp=new LinearLayout.LayoutParams(-1,dp(54));qp.setMargins(0,dp(16),0,dp(12));root.addView(q,qp);TextView count=text(apps.size()+" apps",13,MUTED);root.addView(count);ScrollView sc=new ScrollView(this);GridLayout grid=new GridLayout(this);grid.setColumnCount(4);sc.addView(grid);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));Runnable filter=()->{grid.removeAllViews();String term=q.getText().toString().trim().toLowerCase(Locale.ROOT);int n=0;for(ResolveInfo a:apps)if(name(a).toLowerCase(Locale.ROOT).contains(term)){GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=0;lp.height=dp(106);lp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);grid.addView(tile(a,true),lp);n++;}count.setText(n==0?"No matching apps":n+" apps");};q.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){filter.run();}public void afterTextChanged(Editable e){}});filter.run();}
    void panel(){base("panel");header("Control center");TextView subtitle=text("Inside AV · system shade stays unchanged",12,MUTED);root.addView(subtitle);LinearLayout toggles=new LinearLayout(this);toggles.setPadding(0,dp(18),0,dp(14));toggles.addView(button("Wi-Fi",()->open(new Intent(Settings.ACTION_WIFI_SETTINGS))),new LinearLayout.LayoutParams(0,dp(58),1));toggles.addView(button("Bluetooth",()->open(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS))),new LinearLayout.LayoutParams(0,dp(58),1));toggles.addView(button("Display",()->open(new Intent(Settings.ACTION_DISPLAY_SETTINGS))),new LinearLayout.LayoutParams(0,dp(58),1));root.addView(toggles);
        LinearLayout bar=new LinearLayout(this);bar.addView(text("Notifications",20,INK),new LinearLayout.LayoutParams(0,dp(50),1));bar.addView(button("Manage",()->notificationAccess()));root.addView(bar);
        ScrollView sc=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(1);sc.addView(list);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        if(NotificationBridge.connected==null){TextView empty=text("Your notifications, together\n\nEnable notification access to show active notifications here. AV can read their text, open them, and dismiss them. It does not save or upload notification content.\n\nThe Android notification shade is unchanged.",16,MUTED);empty.setPadding(dp(8),dp(24),dp(8),dp(24));list.addView(empty);list.addView(button("Enable notification access",()->notificationAccess()));return;}
        StatusBarNotification[] ns=NotificationBridge.current();if(ns==null)ns=new StatusBarNotification[0];Arrays.sort(ns,(a,b)->Long.compare(b.getPostTime(),a.getPostTime()));int shown=0;
        for(StatusBarNotification s:ns){if(shown++>=60)break;android.app.Notification n=s.getNotification();LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(18),dp(16),dp(18),dp(12));card.setBackground(shape(Color.WHITE,22));String app=s.getPackageName();try{app=getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(app,0)).toString();}catch(PackageManager.NameNotFoundException ignored){}card.addView(text(app,12,RED));CharSequence title=n.extras.getCharSequence(android.app.Notification.EXTRA_TITLE);CharSequence body=n.extras.getCharSequence(android.app.Notification.EXTRA_TEXT);TextView t=text(title==null?"Notification":title.toString(),16,INK);t.setMaxLines(2);card.addView(t);if(body!=null){TextView b=text(body.toString(),14,MUTED);b.setMaxLines(4);b.setEllipsize(TextUtils.TruncateAt.END);card.addView(b);}if(n.contentIntent!=null){card.setFocusable(true);card.setOnClickListener(v->{try{n.contentIntent.send();}catch(PendingIntent.CanceledException e){Toast.makeText(this,"This notification is no longer available",0).show();panel();}});}if(s.isClearable()){TextView dismiss=button("Dismiss",()->{if(NotificationBridge.connected!=null)NotificationBridge.connected.cancelNotification(s.getKey());});card.addView(dismiss);}LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(12));list.addView(card,cp);}
        if(shown==0)list.addView(text("You're all caught up",18,MUTED));
    }
    void notificationAccess(){new AlertDialog.Builder(this).setTitle("Allow notification access?").setMessage("Android will let AV read active notifications, including private message text, and dismiss them. Content is shown only in this app and is not stored or uploaded. You can revoke access at any time in Settings.").setPositiveButton("Open Android settings",(d,w)->open(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))).setNegativeButton("Cancel",null).show();}
    void settings(){new AlertDialog.Builder(this).setTitle("AV Oxygen Home").setItems(new String[]{"Set default Home app","Phone app & call settings","Notification center","Change system wallpaper"},(d,w)->{if(w==0){RoleManager r=getSystemService(RoleManager.class);if(r!=null&&r.isRoleAvailable(RoleManager.ROLE_HOME))startActivityForResult(r.createRequestRoleIntent(RoleManager.ROLE_HOME),1);else open(new Intent(Settings.ACTION_HOME_SETTINGS));}else if(w==1)startActivity(new Intent(this,DialActivity.class).putExtra("setup",true));else if(w==2)panel();else open(new Intent(Intent.ACTION_SET_WALLPAPER));}).show();}
    void open(Intent i){try{startActivity(i);}catch(ActivityNotFoundException|SecurityException e){Toast.makeText(this,"No available app can open this action",0).show();}}
    @Override public void onBackPressed(){if(!page.equals("home"))home();}
}
