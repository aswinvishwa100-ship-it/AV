package com.av.oxygenhome;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.content.Intent;

/** No storage or networking: notification content stays in Android and the visible screen. */
public class NotificationBridge extends NotificationListenerService {
    static NotificationBridge connected;
    static final String CHANGED="com.av.oxygenhome.NOTIFICATIONS_CHANGED";
    @Override public void onListenerConnected(){connected=this;changed();}
    @Override public void onListenerDisconnected(){connected=null;changed();}
    @Override public void onDestroy(){if(connected==this)connected=null;super.onDestroy();}
    @Override public void onNotificationPosted(StatusBarNotification n){changed();}
    @Override public void onNotificationRemoved(StatusBarNotification n){changed();}
    private void changed(){sendBroadcast(new Intent(CHANGED).setPackage(getPackageName()));}
    static StatusBarNotification[] current(){
        try{return connected==null?new StatusBarNotification[0]:connected.getActiveNotifications();}
        catch(SecurityException e){return new StatusBarNotification[0];}
    }
}
